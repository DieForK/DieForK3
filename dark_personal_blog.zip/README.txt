MIDNIGHT NOTES — Personal Blog

အသုံးပြုပုံ
1. index.html ကို ဖုန်း သို့မဟုတ် ကွန်ပျူတာ browser မှာဖွင့်ပါ။
2. “စာအသစ်ရေးမယ်” မှာ ခေါင်းစဉ်၊ ရက်စွဲ၊ စာသားဖြည့်ပြီး သိမ်းပါ။
3. စာတွေကို ဒီ browser/device ရဲ့ local storage ထဲမှာ သိမ်းပါတယ်။ တခြားသူတွေနဲ့ အလိုအလျောက် မမျှဝေပါ။

အခမဲ့ Online တင်နည်း (GitHub Pages)
1. github.com မှာ account ဖွင့်/ဝင်ပါ။
2. New repository ဖန်တီးပြီး Public လုပ်ပါ။
3. Add file > Upload files ကနေ index.html ကို upload လုပ်ပြီး commit လုပ်ပါ။
4. Repository Settings > Pages သို့သွားပါ။
5. Build and deployment အောက်မှာ Deploy from a branch ကိုရွေးပါ။
6. Branch = main၊ folder = /(root) ရွေးပြီး Save နှိပ်ပါ။
7. မိနစ်အနည်းငယ်စောင့်ပါ။ Pages က ပေးတဲ့ URL ကိုဖွင့်ပြီး Website ကိုစမ်းပါ။

အရေးကြီး
- GitHub Pages မှာ တင်ထားတာက website ဖိုင်တွေကို public ဖြစ်စေပါတယ်။
- ဒီ version မှာ Blog post တွေက visitor အားလုံးအတွက် server ပေါ်မှာ မသိမ်းထားပါ။ တင်ထားတဲ့ browser/device ထဲမှာပဲ သိမ်းပါတယ်။
- Visitor အားလုံးမြင်ရမယ့် shared blog posts, login, admin panel လိုချင်ရင် database/backend ပါတဲ့ version လိုအပ်ပါတယ်။
